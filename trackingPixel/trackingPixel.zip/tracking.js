
var tmd = {};
tmd.pixel = function(){
	var xmlhttp, url, referrer;
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	  //console.log(xmlhttp)
	xmlhttp.onreadystatechange=function()
	  {
		  if (xmlhttp.readyState==4 && xmlhttp.status == 200){  
		  }
	  }
	  
	url=location.href;
	referrer=document.referrer;
	var pixel = new Image();
	pixel.src = 'destination.php'+ '?' + "url="+url+"&referrer="+referrer+"&userid="+uid;
	xmlhttp.open("POST","destination.php",true);
	xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xmlhttp.send("url="+url+"&referrer="+referrer+"&userid="+uid);
}
	