<?php
$uid = $_POST['userid'];
$url = $_POST['url'];
$referrer = $_POST['referrer'];
$ip = $_SERVER['REMOTE_ADDR'];

// Create the Query
if ($url != ""){
	//$query = "INSERT INTO `url` (`url`) VALUES ('$url')";
	$query = "INSERT INTO url (user, ip, url, referrer) VALUES ('$uid','$ip','$url','$referrer')";
	//$query = "INSERT INTO `url` (`date`) VALUES ('$date')";
	
	$host = "localhost";
	$user = "root";
	$pass = "";
	$sdb = "pixel";
	$dbh = mysql_connect($host, $user, $pass) or die (mysql_error());
	mysql_select_db($sdb, $dbh);
	mysql_query($query) or die(mysql_error());
}
?>

